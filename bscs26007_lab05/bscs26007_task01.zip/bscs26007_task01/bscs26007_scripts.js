window.onload = function() {
 alert("Welcome")   
 alert(Date().getFullYear())
}
new Date().getFullYear()

function showAvailability(){
alert("Not Available")
}
function validateForm(){
    <script></script>
}4